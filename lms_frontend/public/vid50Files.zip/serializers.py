from rest_framework import serializers
from . import models

class InstructorSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Instructor
        fields = ['id','full_name', 'email', 'qualification', 'mobile_number', 'password']

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CourseCategory
        fields = ['id','title','description']

class CourseSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Course
        fields = ['id','category','instructor','title','description', 'course_image', 'technologies','course_modules','total_enrolled_students']
        depth = 1 #to retrieve the next level relationship
    
class ModuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Module
        fields = ['id','course','title','description','video','remarks']

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Module
        fields = ['id','full_name', 'email','username','password','interested_categories']

class StudentCourseEnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.StudentCourseEnrollment
        fields = ['id', 'course', 'student', 'enrolled_time']
        depth=1