// import OwnCarousel from 'react-owl-carousel';
// import 'owl.carousel/dist/assets/owl.carousel.css';
// import 'owl.carousel/dist/assets/owl.theme.default.css';
import { Link, useParams } from "react-router-dom"; //A hook to get parameter of the URL and matches with the data from database
import { useState, useEffect } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';

const baseUrl = 'http://127.0.0.1:8000/api';
const siteUrl = 'http://127.0.0.1:8000/';

function CourseDetails(){
    
    const [moduleData, setModuleData] = useState([]);
    const [courseData, setcourseData] = useState([]);
    const [instructorData, setInstructorData] = useState([]);
    const [userLoginStatus, setuserLoginStatus] = useState([]);
    const [enrollStatus, setenrollStatus] = useState([]);
    let {course_id} = useParams();
    const student_id = localStorage.getItem('student_id');
    // Fetch courses
    useEffect(() =>{
        try{
            axios.get(baseUrl+'/course/'+ course_id).then((response) =>
            {
                setcourseData(response.data);
                setInstructorData(response.data.instructor);
                setModuleData(response.data.module);
                // console.log(response.data)
            });
        }
        catch(error){
            console.log(error);
        }

        try{
            axios.get(baseUrl+'/fetch-enroll-status/'+student_id+'/'+course_id).then((response) =>
            {
                console.log('This area')
                console.log(response.data)
                
                if(response.data.bool===true){
                    setenrollStatus('success');
                }
            });
        }
        catch(error){
            console.log(error);
        }
        const studentLoginStatus = localStorage.getItem('studentLoginStatus');
        if(studentLoginStatus==='true'){
            setuserLoginStatus('success');
        }
      
    },[]);

    // Enroll in course
    const enrollCourse = () =>{

        const _formData = new FormData();
        _formData.append('course', course_id);
        _formData.append('student', student_id);
        try{
            axios.post(baseUrl+'/student-enroll-course/', _formData,{
                headers:{
                    'content-type':'multipart/form-data'
                }
            })
            .then((response) => {
                if (response.status===200 || response.status===201){
                       Swal.fire({
                           title: 'You have successfully enrolled in this course!',
                           toast: true,
                           icon: 'success',
                           position:'top-right',
                           showConfirmButton: false,
                           timer:5000,
                           timerProgressBar:true,
                           showCloseButton: true
                         });
                }
               //window.location.href = '/edit-module/1'
           });
        }catch(error){
            console.log(error);
        }
    
    }
    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-2">
                    <img src={courseData.course_image} className="img-thumbnail" alt="..."/>
                </div>
                <div className="col-10">
                    <h3>{courseData.title}</h3>
                    <p>{courseData.description}</p>
                    <p className="mb-1 fw-bold fs-6">Course By: <Link to = {`/instructor-course-detail/${instructorData.id}`}>{instructorData.full_name}</Link></p>
                    <p className="mb-1 fw-bold fs-6">Total Enrolled: {courseData.total_enrolled_students} Student(s)</p>
                    {
                        enrollStatus === 'success' && userLoginStatus==='success' &&
                        <p><span>You are already enrolled in this course</span></p>
                    }
                    { userLoginStatus==='success' && enrollStatus !== 'success' &&
                    <p><button type='button' onClick={enrollCourse} className="btn btn-success">Enroll in this Course</button> </p>
                    }
                    
                    { userLoginStatus !=='success' && 
                    <p><Link to='/user-login/' >Please Login to enroll</Link> </p>
                    }
                    </div>
            </div>
            <div className="card">
                <div className="card-header">
                    <h5> More Details </h5>
                </div>
                <ul className="list-group list-group-flush">
                {
                        enrollStatus === 'success' && userLoginStatus==='success' &&
                    <li className="list-group-item" key={module.id}>{module.title}
                        <button type="button" className="btn btn-sm  btn-dark float-end" data-bs-toggle = 'modal'
                        data-bs-target= '#videoModal'>
                        <i className="bi-play-circle-fill"></i></button>
                        {/* For video  */}
                        <div className="modal fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div className="modal-dialog modal-lg">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h1 className="modal-title fs-5" id="exampleModalLabel">{module.video}</h1>
                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                <div className="ratio ratio-16x9">
                                    <iframe src={module.video} title="YouTube video" allowfullscreen></iframe>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                    </li>
                    }
                </ul>
            </div>
            {/* Can add related courses if needed */}
        </div>

    );
}

export default CourseDetails;